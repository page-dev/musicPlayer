package com.example.music7.Interfaces;

import android.content.Context;

import com.example.music7.Playlist.PlaylistContainer;

public interface OnPlaylistClick {
    public void onPlaylistClick(PlaylistContainer playlistContainer, int position, Context context);
}
