package com.example.music7.Fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.music7.Interfaces.OnPlaylistClick;
import com.example.music7.Playlist.Playlist;
import com.example.music7.Playlist.PlaylistAdapter;
import com.example.music7.Playlist.PlaylistContainer;
import com.example.music7.R;
import com.example.music7.Track.TrackContainer;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class PlaylistsFragment extends Fragment implements OnPlaylistClick {
    public ArrayList<PlaylistContainer> allPlaylists = new ArrayList<>();
    RecyclerView playlistsRecyclerView;
    private OnPlaylistClick listener;
    FloatingActionButton addPlaylist;
//    private PlaylistDBHelper dbHelper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_playlists, container, false);

        playlistsRecyclerView = view.findViewById(R.id.playlist_recyclerview);
        addPlaylist = view.findViewById(R.id.playlist_add_button);
        
        addPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "add playlist", Toast.LENGTH_SHORT).show();
            }
        });

//        Recycler init

        playlistsRecyclerView.setLayoutManager(new GridLayoutManager(view.getContext(), 3));
        playlistsRecyclerView.setAdapter(new PlaylistAdapter(requireContext(), allPlaylists, this::onPlaylistClick));

        return view;
    }

    @Override
    public void onPlaylistClick(PlaylistContainer playlistContainer, int position, Context context) {
        Toast.makeText(context, "go to playlist, make it fragment", Toast.LENGTH_SHORT).show();
    }
}