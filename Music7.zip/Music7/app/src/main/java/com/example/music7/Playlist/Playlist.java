package com.example.music7.Playlist;

import com.example.music7.Track.TrackContainer;

import java.util.ArrayList;

public class Playlist {
    String playlistName;
    ArrayList<TrackContainer> playlistTracks;
    int playlistCover;

    public Playlist(String playlistName, ArrayList<TrackContainer> playlistTracks, int playlistCover) {
        this.playlistName = playlistName;
        this.playlistTracks = playlistTracks;
        this.playlistCover = playlistCover;
    }

    public String getPlaylistName() {
        return playlistName;
    }

    public void setPlaylistName(String playlistName) {
        this.playlistName = playlistName;
    }

    public ArrayList<TrackContainer> getPlaylistTracks() {
        return playlistTracks;
    }

    public void setPlaylistTracks(ArrayList<TrackContainer> playlistTracks) {
        this.playlistTracks = playlistTracks;
    }

    public int getPlaylistCover() {
        return playlistCover;
    }

    public void setPlaylistCover(int playlistCover) {
        this.playlistCover = playlistCover;
    }
}
