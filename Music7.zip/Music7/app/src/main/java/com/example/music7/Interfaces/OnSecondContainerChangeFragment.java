package com.example.music7.Interfaces;

public interface OnSecondContainerChangeFragment {
    void secondContainerChangeFragment(int tabnumber);
}
