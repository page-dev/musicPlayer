package com.example.music7.Track;

import java.io.Serializable;

public class TrackContainer implements Serializable {
    private Track track;

    public TrackContainer(Track track) {
        this.track = track;
    }

    public Track getTrack() {
        return track;
    }

    public void setTrack(Track track) {
        this.track = track;
    }
}
