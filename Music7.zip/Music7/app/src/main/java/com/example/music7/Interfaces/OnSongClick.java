package com.example.music7.Interfaces;

import android.content.Context;

import com.example.music7.Track.TrackContainer;

public interface OnSongClick {
    public void onSongClick(TrackContainer trackContainer, int position, Context context);
}
