package com.example.music7.Track;

import java.util.Comparator;

public class Track {
    private String name, artist, album, duration, path;
    private int image;
    private boolean favorite;

    public Track(String name, String artist, String album, String duration, String path, int image) {
        this.name = name;
        this.artist = artist;
        this.album = album;
        this.duration = duration;
        this.path = path;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

//    Inner comparator class for sorting
    public static class NameComparator implements Comparator<Track>{
        @Override
        public int compare(Track o1, Track o2) {
            return o1.getName().trim().toLowerCase().compareTo(o2.getName().trim().toLowerCase());
        }
    }
}
