package com.example.music7.Player;

import android.media.MediaPlayer;

public class MyMediaPlayer {
    public static MediaPlayer instance;
    public static int currentIndex = -1, clickedTrackPosition, prevIndex = -1;
    public static boolean isLooping = false, isPaused;

    public static MediaPlayer getInstance(){
        if (instance == null){
            instance = new MediaPlayer();
        }
        return instance;
    }
}
