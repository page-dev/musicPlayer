package com.example.music7.Interfaces;

public interface MiniPlayerFragmentListener {
    public void onMiniPlayerFragmentReady();
}
