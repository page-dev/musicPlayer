package com.example.music7.Interfaces;

public interface QueueFragmentListener {
    public void onQueueFragmentReady();
}
