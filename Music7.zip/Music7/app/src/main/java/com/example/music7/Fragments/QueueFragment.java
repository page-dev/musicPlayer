package com.example.music7.Fragments;

import static com.example.music7.MainActivity.fragmentContainerView;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.music7.Interfaces.MediaControls;
import com.example.music7.Interfaces.MiniPlayerFragmentListener;
import com.example.music7.Interfaces.OnDotsClick;
import com.example.music7.Interfaces.OnSecondContainerChangeFragment;
import com.example.music7.Interfaces.OnSongClick;
import com.example.music7.Interfaces.QueueFragmentListener;
import com.example.music7.MainActivity;
import com.example.music7.Player.MyMediaPlayer;
import com.example.music7.Queue.QueueAdapter;
import com.example.music7.R;
import com.example.music7.Songs.SongsAdapter;
import com.example.music7.Track.TrackContainer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;


public class QueueFragment extends Fragment implements OnSongClick, OnDotsClick, MediaControls {
    TextView queueCurrentTime, queueTotalTime;
    SeekBar queueSeekbar;
    ImageView queuePausePlay, queueNextTrack, queuePrevTrack, queueShuffleQueue, queueLoopQueue, queueBack;
    public static RecyclerView queueRecyclerView;
    public static TrackContainer currentTrack;
    MediaPlayer mediaPlayer = MyMediaPlayer.getInstance();
    QueueAdapter queueAdapter;
    LinearLayoutManager layoutManager;
    private OnSecondContainerChangeFragment listener;
    public static ArrayList<TrackContainer> queue = new ArrayList<>();
    private QueueFragmentListener queueFragmentListener;
    private MiniPlayerFragmentListener miniPlayerFragmentListener;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_queue, container, false);
//        Register touches only in this fragment, not pass through it
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_MOVE){
                    return false;
                }
                return true;
            }
        });

        queueCurrentTime = view.findViewById(R.id.queue_current_time);
        queueTotalTime = view.findViewById(R.id.queue_total_time);
        queueSeekbar = view.findViewById(R.id.queue_seek_bar);
        queuePausePlay = view.findViewById(R.id.queue_play_pause);
        queueNextTrack = view.findViewById(R.id.queue_next);
        queuePrevTrack = view.findViewById(R.id.queue_previous);
        queueShuffleQueue = view.findViewById(R.id.queue_shuffle);
        queueLoopQueue = view.findViewById(R.id.queue_loop);
        queueBack = view.findViewById(R.id.queue_back);
        queueRecyclerView = view.findViewById(R.id.queue_recycler_view);
        
        queueBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Handler handler = new Handler();
                handler.removeCallbacksAndMessages(null);
                Fragment fragment = requireActivity().getSupportFragmentManager().findFragmentByTag("QueueFragment");
                requireActivity().getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(R.anim.enter_bottom_to_top, R.anim.exit_top_to_bottom)
                        .remove(fragment)
                        .commit();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.layoutParams.height = RelativeLayout.LayoutParams.WRAP_CONTENT;
                        MainActivity.fragmentContainerView.setLayoutParams(MainActivity.layoutParams);
                    }
                }, 500);
                listener.secondContainerChangeFragment(5);
            }
        });


        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null){
                    queueSeekbar.setProgress(mediaPlayer.getCurrentPosition());
                    queueCurrentTime.setText(convertToTimeFormat(String.valueOf(mediaPlayer.getCurrentPosition())));
                    if (mediaPlayer.isPlaying()){
                        queuePausePlay.setImageResource(R.drawable.pause_circle);
                    } else {
                        queuePausePlay.setImageResource(R.drawable.play_circle);
                    }
                }
                handler.postDelayed(this, 100);
            }
        });

        queueSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (mediaPlayer != null && fromUser){
                    mediaPlayer.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        queueFragmentListener.onQueueFragmentReady();
        setupPlayer();

        return view;
    }

    public ArrayList<TrackContainer> getQueue() {
        return queue;
    }

    public void setQueue(ArrayList<TrackContainer> tracks){
        queue = tracks;
    }

    public void addToQueue(TrackContainer track){
        queue.add(track);
    }

    private void recyclerViewInit(ArrayList<TrackContainer> queue){
        layoutManager = new LinearLayoutManager(getContext());
        queueRecyclerView.setLayoutManager(layoutManager);
        if (MyMediaPlayer.prevIndex == -1){
            layoutManager.scrollToPosition(MyMediaPlayer.currentIndex);
        }
        queueAdapter = new QueueAdapter(requireContext(), queue, this::onSongClick, this::onDotsClick);
        queueRecyclerView.setAdapter(new SongsAdapter(requireContext(), queue, this::onSongClick, this::onDotsClick));
        queueRecyclerView.setAdapter(queueAdapter);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnSecondContainerChangeFragment) {
            listener = (OnSecondContainerChangeFragment) context;
        }
        if (context instanceof QueueFragmentListener) {
            queueFragmentListener = (QueueFragmentListener) context;
        }
        if (context instanceof MiniPlayerFragmentListener){
            miniPlayerFragmentListener = (MiniPlayerFragmentListener) context;
        }
    }

    @Override
    public void onSongClick(TrackContainer trackContainer, int position, Context context) {
        mediaPlayer.setOnCompletionListener(null);
        MyMediaPlayer.getInstance().reset();
        MyMediaPlayer.prevIndex = MyMediaPlayer.currentIndex;
        MyMediaPlayer.clickedTrackPosition = position;
//        MyMediaPlayer.currentIndex = position;

        int scrollPosition = layoutManager.findFirstVisibleItemPosition();
        setupPlayer();
        layoutManager.scrollToPositionWithOffset(scrollPosition, 0);

    }

    @Override
    public void onDotsClick(TrackContainer trackContainer, int position, Context context, View v) {
        showPopMenu(v);
    }

    @Override
    public void playTrack() {
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(currentTrack.getTrack().getPath());
            mediaPlayer.prepare();
            mediaPlayer.start();
            queueSeekbar.setProgress(0);
            queueSeekbar.setMax(mediaPlayer.getDuration());
            if (((MiniPlayerFragment) requireActivity().getSupportFragmentManager().findFragmentByTag("MiniPlayerFragment")) != null){
                miniPlayerFragmentListener.onMiniPlayerFragmentReady();
            }
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    if (MyMediaPlayer.currentIndex == queue.size() - 1){
                        getActivity().getSupportFragmentManager().popBackStack();
                        MainActivity.fragmentContainerView.setVisibility(View.GONE);
                    } else {
                        playNextTrack();
                    }
                    queueAdapter.notifyDataSetChanged();
                }
            });
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void setupPlayer() {
        MyMediaPlayer.prevIndex = MyMediaPlayer.currentIndex;
        if ((MyMediaPlayer.currentIndex == -1 && MyMediaPlayer.prevIndex == -1) // first click
        || ((MyMediaPlayer.currentIndex != MyMediaPlayer.clickedTrackPosition) && MyMediaPlayer.prevIndex != -1) // there is current playing, then song is clicked
        ){
            MyMediaPlayer.currentIndex = MyMediaPlayer.clickedTrackPosition;
        }
        recyclerViewInit(queue);
        setupControls();
        if (!mediaPlayer.isPlaying()) playTrack();
    }

    @Override
    public void setupControls() {
        currentTrack = queue.get(MyMediaPlayer.currentIndex);
        queueSeekbar.setProgress(0);
        queueSeekbar.setMax(mediaPlayer.getDuration());
        queueTotalTime.setText(convertToTimeFormat(currentTrack.getTrack().getDuration()));
        queuePausePlay.setOnClickListener(v-> pausePlay());
        queueNextTrack.setOnClickListener(v-> playNextTrack());
        queuePrevTrack.setOnClickListener(v-> playPreviousTrack());
        queueShuffleQueue.setOnClickListener(v-> shuffleQueue());
        queueLoopQueue.setOnClickListener(v-> loopQueue());

        queueAdapter.notifyDataSetChanged();
    }

    @Override
    public void playNextTrack() {
        if (MyMediaPlayer.currentIndex == queue.size() - 1){
            mediaPlayer.stop();
            mediaPlayer.reset();
            return;
        }
        MyMediaPlayer.currentIndex += 1;
        MyMediaPlayer.clickedTrackPosition += 1;
        mediaPlayer.reset();
        setupControls();
        playTrack();
    }

    @Override
    public void playPreviousTrack() {
        if (MyMediaPlayer.currentIndex == 0){
            return;
        }
        MyMediaPlayer.currentIndex -= 1;
        MyMediaPlayer.clickedTrackPosition -= 1;
        mediaPlayer.reset();
        setupControls();
        playTrack();
    }

    @Override
    public void pausePlay() {
        // TODO: 08/05/2024 when pausing in miniplayer and click queue, it will restart music 
        if (mediaPlayer.isPlaying()){
            mediaPlayer.pause();
        } else {
            mediaPlayer.start();
        }
    }

    @Override
    public void shuffleQueue() {
        // TODO: 04/05/2024 not workign as expected
        //        set current track to index 0
        swapTracks(0, MyMediaPlayer.currentIndex);
        MyMediaPlayer.currentIndex = 0;
//        shuffle starting idx 1 because 0 is currently playing
        Random rand = new Random();
        for (int i = 1; i < queue.size(); i++) {
            int j = rand.nextInt(i) + 1;
            swapTracks(i, j);
        }
        queueAdapter.notifyDataSetChanged();
        layoutManager.scrollToPosition(MyMediaPlayer.currentIndex);
    }

    @Override
    public void swapTracks(int i, int j) {
        TrackContainer temp = queue.get(i);
        queue.set(i, queue.get(j));
        queue.set(j, temp);
    }

    @Override
    public void loopQueue() {
        MyMediaPlayer.isLooping = !MyMediaPlayer.isLooping;
        mediaPlayer.setLooping(MyMediaPlayer.isLooping);
        if (MyMediaPlayer.isLooping) {
            Toast.makeText(getActivity(), "Looping enabled", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getActivity(), "Looping disabled", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public String convertToTimeFormat(String duration) {
        Long millis = Long.parseLong(duration);
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millis) % TimeUnit.HOURS.toMinutes(1),
                TimeUnit.MILLISECONDS.toSeconds(millis) % TimeUnit.MINUTES.toSeconds(1));
    }

    private void showPopMenu(View v){
        PopupMenu popupMenu = new PopupMenu(getContext(), v);
        popupMenu.getMenuInflater().inflate(R.menu.queue_fragment_popup, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.songs_fragment_add_playlist) {
                    Toast.makeText(getActivity(), "Menu Item 1 clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (item.getItemId() == R.id.songs_fragment_add_queue) {
                    Toast.makeText(getActivity(), "Menu Item 2 clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (item.getItemId() == R.id.songs_fragment_add_favorites) {
                    Toast.makeText(getActivity(), "Menu Item 3 clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else {
                    return false;
                }
            }
        });
        popupMenu.show();
    }




}